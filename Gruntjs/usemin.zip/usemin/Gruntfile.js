module.exports = function(grunt){

	require('load-grunt-tasks')(grunt);

	grunt.initConfig({

		useminPrepare:{
			html:'app/index.html',
			options:{
				dest:'bulid'
			}
		},

		usemin:{
			html:'bulid/index.html'
		},

		copy:{
			task0:{
				src:'app/index.html',
				dest:'bulid/index.html'
			}
		}

	});


	grunt.registerTask('bulid',[
		
		'copy:task0',
		'useminPrepare',
		'concat',
		'cssmin',
		'uglify',
		'usemin'
	]);

}