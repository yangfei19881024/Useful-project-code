;function substrat(a,b){
	return a-b;
}
