(function(){

	var utilA = {

		fun1:function(){
			console.log("this is fun1");
		},

		fun2:function(){
			console.log("this is fun2");
		}

	}

})();