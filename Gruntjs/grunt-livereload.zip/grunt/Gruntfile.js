module.exports = function(grunt){

	require('time-grunt')(grunt);
	require('load-grunt-tasks')(grunt);

		var config = {
			'app':'app',
			'dist':'dist'
		};

	grunt.initConfig({
		config:config,
		sass:{
			compile:{
				// files:{
				// 	"<%= config.dist %>/style.css":'<%= config.app %>/style.scss'
				// }
				src:'<%= config.app %>/style.scss',
				dest:'<%= config.dist %>/style.css'
			}
		},

		clean:{
			clean_task:{
				files:[{
					src:'<%= config.dist%>/**/*',
					filter:function(filepath){
						return (!grunt.file.isDir(filepath))
					}
				}]
			}
		},

		watch:{
			options:{
				livereload:true
			},
			scripts:{
				files:['<%=config.app%>/*.scss'],
				tasks:['sass']
			}
		},

		express:{
			all:{
				options:{
					port:3000,
					hostname:'localhost',
					bases:'.',
					livereload:true,
				}
			}
		}

	});

	// grunt.loadNpmTasks('grunt-contrib-sass');

	grunt.registerTask('default',['watch']);
	grunt.registerTask('server',['express','watch']);

}
